/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Us
 */
public class DBConnection {
     public static Connection initializaDatabase() throws ClassNotFoundException, SQLException 
    {
        //
      Class.forName("com.mysql.jdbc.Driver");
      Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_project","root","root123");
      return con;
    }
}
