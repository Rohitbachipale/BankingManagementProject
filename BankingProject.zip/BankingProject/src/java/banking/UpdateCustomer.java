
package banking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdateCustomer extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
       
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UpdateCustomer</title>");            
            out.println("</head>");
            out.println("<body>");
            int cust_id=Integer.parseInt(request.getParameter("cust_id"));
            String cust_name=request.getParameter("cust_name");
            String email_id=request.getParameter("email_id");
            String password=request.getParameter("password");
            String bank_name=request.getParameter("bank_name");
            float balance=Float.parseFloat(request.getParameter("balance"));
            out.println("Customer_id: "+cust_id+"Customer_name: "+cust_name+"Email ID:"+email_id+"Password:"+password+"Bank Name:"+bank_name+"Balance:"+balance); 
            Connection con = DBConnection.initializaDatabase();
            String sql = "UPDATE customer SET cust_name=?,email_id=?,password=?,bank_name=?,balance=? where cust_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(6, cust_id);
            ps.setString(1, cust_name);
            ps.setString(2, email_id);
            ps.setString(3, password);
            ps.setString(4, bank_name);
            ps.setFloat(5,balance);
            int i = ps.executeUpdate();
            if (i > 0) {
                out.println("<script>alert('Record Updated!');</script>");
            } else {
                out.println("<script>alert('Record Not Update!');</script>");
            }
            con.close();
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(UpdateCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(UpdateCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

  
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
